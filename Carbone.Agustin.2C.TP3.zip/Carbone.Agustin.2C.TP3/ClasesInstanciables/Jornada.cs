﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClasesInstanciables.Universidad;
using Archivos;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private EClases clase;
        private Profesor instructor;

        // propiedades

        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }

            set
            {
                this.alumnos = value;
            }
        }

        public EClases Clase
        {
            get
            {
                return this.clase;
            }

            set
            {
                this.clase = value;
            }
        }

        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }

            set
            {
                this.instructor = value;
            }
        }

        // constructores

        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }

        public Jornada(EClases clase, Profesor instructor) : this()
        {
            this.Clase = clase;
            this.Instructor = instructor;
        }

        // métodos

        public static bool Guardar(Jornada jornada)
        {
            bool retorno = false;
            IArchivo<string> archivo = new Texto();
                        
            if (archivo.Guardar("Archivo.txt", jornada.ToString()))
            {
                retorno = true;
            }

            return retorno;
        }

        public string Leer()
        {
            IArchivo<string> archivo = new Texto();
            string datos;
            archivo.Leer("Archivo.txt", out datos);

            return datos;
        }

        // sobrecargas

        public static bool operator ==(Jornada j, Alumno a)
        {
            bool retorno = false;

            if (a == j.clase)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            Jornada retorno = j;

            if (j != a)
            {
                retorno.alumnos.Add(a);
            }

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Jornada:");

            retorno.AppendFormat("Clase de {0} Por {1}",this.Clase.ToString(), this.Instructor.ToString());

            retorno.AppendLine("Alumnos:");

            foreach (Alumno alumno in this.alumnos)
            {
                retorno.AppendLine(alumno.ToString());
            }

            retorno.AppendLine("<----------------------------------------->\n");

            return retorno.ToString();
        }
    }
}
