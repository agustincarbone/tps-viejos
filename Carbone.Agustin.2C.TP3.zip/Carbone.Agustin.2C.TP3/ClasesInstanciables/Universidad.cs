﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Universidad
    {
        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        // propiedades

        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }

            set
            {
                this.Alumnos = value;
            }
        }

        public List<Profesor> Instructores
        {
            get
            {
                return this.profesores;
            }

            set
            {
                this.Instructores = value;
            }
        }

        public List<Jornada> Jornadas
        {
            get
            {
                return this.jornada;
            }

            set
            {
                this.jornada = value;
            }
        }

        public Jornada this[int i]
        {
            get
            {
                return this.jornada.ElementAt(i);
            }

            set
            {
                this.jornada.Insert(i, value);
            }
        }

        // constructores

        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.jornada = new List<Jornada>();
            this.profesores = new List<Profesor>();
        }

        // métodos

        public static bool Guardar(Universidad uni)
        {
            bool retorno;

            IArchivo<Universidad> archivo = new Xml<Universidad>();

            retorno = archivo.Guardar("Archivo.xml", uni);

            return retorno;
        }

        public string Leer()
        {
            IArchivo<Universidad> archivo = new Xml<Universidad>();
            Universidad datos;
            archivo.Leer("Archivo.xml", out datos);

            return datos.ToString();
        }

        private static string MostrarDatos(Universidad uni)
        {
            StringBuilder retorno = new StringBuilder();
                        
            foreach (Jornada jornada in uni.Jornadas)
            {
                retorno.AppendLine(jornada.ToString());
            }

            return retorno.ToString();
        }

        // sobrecargas

        public static bool operator ==(Universidad g, Alumno a)
        {
            bool retorno = false;

            foreach (Alumno alumnoAux in g.Alumnos)
            {
                if(alumnoAux == a)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        public static Universidad operator +(Universidad g, Alumno a)
        {
            Universidad retorno = g;

            if (g != a)
            {
                retorno.Alumnos.Add(a);
            }
            else
            {
                throw new AlumnoRepetidoException();
            }

            return retorno;
        }

        public static bool operator ==(Universidad g, Profesor i)
        {
            bool retorno = false;

            foreach (Profesor auxProfesor in g.Instructores)
            {
                if (auxProfesor == i)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        public static Universidad operator +(Universidad g, Profesor i)
        {
            Universidad retorno = g;

            if (g != i)
            {
                retorno.Instructores.Add(i);
            }

            return retorno;
        }

        public static Profesor operator ==(Universidad u, EClases clase)
        {
            Profesor retorno = null;

            foreach (Profesor profesor in u.Instructores)
            {
                if (profesor == clase)
                {
                    retorno = profesor;
                    break;
                }
            }

            if (retorno is null)
            {
                throw new SinProfesorException();
            }

            return retorno;
        }

        public static Profesor operator !=(Universidad u, EClases clase)
        {
            Profesor retorno = null;

            foreach (Profesor profesor in u.Instructores)
            {
                if (profesor != clase)
                {
                    retorno = profesor;
                    break;
                }
            }

            if (retorno is null)
            {
                throw new SinProfesorException();
            }

            return retorno;
        }

        public static Universidad operator +(Universidad g, EClases clase)
        {
            Universidad retorno = g;
            Jornada jornada;

            jornada = new Jornada(clase, g == clase);
            foreach (Alumno alumno in g.Alumnos)
            {
                if (alumno == clase)
                {
                    jornada.Alumnos.Add(alumno);
                }
            }

            retorno.jornada.Add(jornada);

            return retorno;
        }

        public override string ToString()
        {
            return MostrarDatos(this);
        }

        // enumerados

        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }
    }
}
