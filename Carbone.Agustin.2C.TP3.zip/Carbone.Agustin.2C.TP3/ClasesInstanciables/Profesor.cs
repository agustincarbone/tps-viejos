﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
using static ClasesInstanciables.Universidad;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<EClases> clasesDelDia;
        private static Random random;

        // constructores

        static Profesor()
        {
            random = new Random();
        }

        public Profesor()
        {
            this.clasesDelDia = new Queue<EClases>();
            this._randomClases();

        }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this()
        {
            this.legajo = id;
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.StringToDNI = dni;
            this.Nacionalidad = nacionalidad;
        }

        // métodos

        private void _randomClases()
        {
            var array = Enum.GetValues(typeof(EClases));
            this.clasesDelDia.Enqueue((EClases)array.GetValue(random.Next(array.Length)));
            this.clasesDelDia.Enqueue((EClases)array.GetValue(random.Next(array.Length)));
        }

        // sobrecargas

        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("{0}{1}\n", base.MostrarDatos(), this.ParticiparEnClase());

            return retorno.ToString();
        }

        public static bool operator ==(Profesor i, EClases clase)
        {
            bool retorno = false;

            foreach (EClases auxClase in i.clasesDelDia)
            {
                if (auxClase == clase)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Profesor i, EClases clase)
        {
            return !(i == clase);
        }

        protected override string ParticiparEnClase()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Clases del Dia");

            foreach (EClases clase in clasesDelDia)
            {
                retorno.AppendLine(clase.ToString());
            }

            return retorno.ToString();
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}
