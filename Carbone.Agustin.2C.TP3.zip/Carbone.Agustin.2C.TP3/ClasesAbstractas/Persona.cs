﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;

        // propiedades

        public string Nombre
        {
            get
            {
                return this.nombre;
            }

            set
            {
                this.nombre = value;
            }
        }

        public string Apellido
        {
            get
            {
                return this.apellido;
            }

            set
            {
                this.apellido = value;
            }
        }

        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }

            set
            {
                this.nacionalidad = value;
            }
        }

        public int DNI
        {
            get
            {
                return this.dni;
            }

            set
            {
                this.dni = this.ValidarDni(this.Nacionalidad, value);
            }
        }

        public string StringToDNI
        {
            set
            {
                ValidarDni(this.Nacionalidad, value);
            }
        }

        // constructores

        public Persona()
        { }

        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        { }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        { }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        { }

        // sobrecargas

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("Nombre Completo:{0}, {1}\nNacionalidad: {2}\n", this.Apellido, this.Nombre, this.Nacionalidad);
            return retorno.ToString();
        }

        //validaciones

        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno = -1;

            if (nacionalidad == ENacionalidad.Argentino && dato <= 89999999 && dato >= 1)
            {
                retorno = dato;
            }
            else if (nacionalidad == ENacionalidad.Extranjero && dato >= 90000000 && dato <= 99999999)
            {
                retorno = dato;
            }
            else if(dato > 99999999 || dato < 1)
            {
                throw new DniInvalidoException();
            }
            else
            {
                throw new NacionalidadInvalidaException();
            }

            return retorno;
        }

        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int datoAux;
            int retorno = -1;

            if (dato.Count() == 8)
            {
                if (int.TryParse(dato, out datoAux) == true)
                {
                    this.DNI = datoAux;
                }
                else
                {
                    throw new DniInvalidoException("el DNI contiene caracteres no validos");
                }
            }
            else if(dato.Count() < 8)
            {
                throw new DniInvalidoException("el DNI contiene menos de 8 caracteres");
            }
            else if (dato.Count() > 8)
            {
                throw new DniInvalidoException("el DNI contiene mas de 8 caracteres");
            }

            return retorno;
        }

        private string ValidarNombreApellido(string dato)
        {
            string retorno = null;
            int contador = 0;

            foreach (char caracter in dato)
            {
                if (caracter > 'a' && caracter < 'z')
                {
                    contador++;
                }
            }

            if (contador == dato.Count())
            {
                retorno = dato;
            }

            return retorno;
        }

        // enumerados

        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
    }
}
