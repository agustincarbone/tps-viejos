﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class ArchivosException : Exception
    {
        private string message;

        public override string Message
        {
            get
            {
                return this.message;
            }
        }
        public ArchivosException(Exception innerException)
        {
            this.message = innerException.Message;
        }
    }
}
