﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException : Exception
    {
        private string mensajeBase;
        private string mensaje;

        public string Mensaje
        {
            get
            {
                StringBuilder retorno = new StringBuilder();

                retorno.AppendFormat("{0}\n{1}", this.mensajeBase, this.mensaje);
                return retorno.ToString();
            }
        }

        public DniInvalidoException()
        {
            this.mensaje = "el DNI no es valido";
        }

        public DniInvalidoException(Exception e) : this()
        {
            this.mensajeBase = e.Message;
        }

        public DniInvalidoException(string message)
        {
            this.mensaje = message;
        }

        public DniInvalidoException(string message, Exception e) : this(message)
        {
            this.mensajeBase = e.Message;
        }
    }
}
