﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        bool IArchivo<string>.Guardar(string archivo, string datos)
        {
            bool retorno = false;

            try
            {
                StreamWriter texto = File.AppendText(archivo);

                texto.WriteLine(datos);

                texto.Close();

                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }

        bool IArchivo<string>.Leer(string archivo, out string datos)
        {
            bool retorno = false;
            string linea;

            try
            {
                StreamReader texto = File.OpenText(archivo);
                StringBuilder auxiliar = new StringBuilder();
                
                    linea = texto.ReadToEnd();

                    if (linea != null)
                    {
                        auxiliar.AppendLine(linea);
                    }

                texto.Close();

                datos = auxiliar.ToString();

                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }
    }
}
