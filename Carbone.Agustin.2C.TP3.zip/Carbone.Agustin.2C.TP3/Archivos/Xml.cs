﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using Excepciones;

namespace Archivos
{
    [Serializable]
    public class Xml<T> : IArchivo<T>
    {
        bool IArchivo<T>.Guardar(string archivo, T datos)
        {
            bool retorno = false;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                TextWriter texto = new StreamWriter(archivo);
                serializer.Serialize(texto, datos);
                texto.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }

        bool IArchivo<T>.Leer(string archivo, out T datos)
        {
            bool retorno = false;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                TextReader texto = new StreamReader(archivo);
                datos = (T)serializer.Deserialize(texto);
                texto.Close();

                retorno = true;
            }
            catch (Exception e)
            {
                datos = default(T);
                throw new ArchivosException(e);
            }

            return retorno;
        }
    }
}
