﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class PaqueteDAO
    {
        private static SqlConnection conexion = new SqlConnection("Data Soucre=.\\SQLEXPRESS;Initial Catalog=correo-sp-2017;Integrated Security=true");
        private static SqlCommand comando = new SqlCommand();


        static PaqueteDAO()
        {
            PaqueteDAO.comando.CommandType = CommandType.Text;
            PaqueteDAO.comando.Connection = PaqueteDAO.conexion;
        }

        public static bool Insertar(Paquete p)
        {
            string str = "INSERT INTO Paquetes (direccionEntrega,trackingId,alumno) VALUES(" + "'" + p.DireccionEntrega + "','" + p.TrackingID + "','profesor')";
            try
            {
                PaqueteDAO.comando.CommandText = str;
                PaqueteDAO.conexion.Open();
                PaqueteDAO.comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (PaqueteDAO.conexion.State == ConnectionState.Open)
                {
                    PaqueteDAO.conexion.Close();
                }
            }
            return true;
        }
    }
}
