using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PruebaInstancia
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void InstanciaIsTrue()
        {
            Correo correo = new Correo();

            Assert.IsNotNull(correo);
        }

        [TestMethod]
        public void PaqueteRepetido()
        {
            Correo correo = new Correo();

            Paquete p1 = new Paquete("abc", "123");
            Paquete p2 = new Paquete("abc", "123");

            try
            {
                correo += p1;
                correo += p2;
            }
            catch(TrackingIdRepetidoException)
            {
                Assert.IsTrue(true);
            }


        }
    }
}
