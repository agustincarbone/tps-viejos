﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ClassLibrary
{
    public class Correo : IMostrar<List<Paquete>>
    {
        private List<Paquete> paquetes;
        private List<Thread> mockPaquetes;

        public List<Paquete> Paquetes
        {
            get
            {
                return this.paquetes;
            }

            set
            {
                this.paquetes = value;
            }
        }

        public Correo()
        {
            this.paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }

        /// <summary>
        /// finaliza todos los hilos activos
        /// </summary>
        public void FinEntregas()
        {
            foreach (Thread hilo in this.mockPaquetes)
            {
                if (hilo.IsAlive)
                {
                    hilo.Abort();
                }
            }
        }

        /// <summary>
        /// muestra los datos del paquete
        /// </summary>
        /// <param name="elementos"> lista de paquetes a mostrar </param>
        /// <returns> retorna un string con los datos </returns>
        public string MostrarDatos(IMostrar<List<Paquete>> elementos)
        {
            List<Paquete> paquetes = ((Correo)elementos).paquetes;
            StringBuilder retorno = new StringBuilder();

            foreach (Paquete paquete in paquetes)
            {
                retorno.AppendLine(string.Format("{0} para {1} ({2})", paquete.TrackingID, paquete.DireccionEntrega, paquete.Estado.ToString()));
            }

            return retorno.ToString();
        }

        public static Correo operator +(Correo c, Paquete p)
        {
            foreach (Paquete paquete in c.paquetes)
            {
                if (p == paquete)
                {
                    throw new TrackingIdRepetidoException("El Tracking ID " + p.TrackingID + " ya esta en la lista de envios ");
                }
            }

            c.paquetes.Add(p);
            Thread thread = new Thread(p.MockCicloDeVida);
            thread.Start();
            c.mockPaquetes.Add(thread);
            return c;
        }

    }
}
