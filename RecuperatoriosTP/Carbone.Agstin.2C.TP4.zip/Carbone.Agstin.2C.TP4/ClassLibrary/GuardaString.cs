﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class GuardaString
    {
        /// <summary>
        /// guarda el texto recibido en un archivo
        /// </summary>
        /// <param name="texto"> informacion que se va a guardar </param>
        /// <param name="archivo"> nombre del archivo </param>
        /// <returns> retorna true si se guardo, false si no </returns>
        public static bool Guardar(this string texto, string archivo)
        {
            bool retorno;

            try
            {
                using (StreamWriter streamWriter = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + (object)Path.DirectorySeparatorChar + archivo, true))
                    streamWriter.WriteLine(texto);

                retorno = true;
            }
            catch (Exception)
            {
                retorno = false;
            }

            return retorno;
        }
    }
}
