﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    /// <summary>
    /// excepcion que se produce cuando el alumno ya esta inscripto
    /// </summary>
    public class AlumnoRepetidoException : Exception
    {
        private string message = "alumno repetido";

        /// <summary>
        /// devuelve el mensaje de error
        /// </summary>
        public override string Message
        {
            get
            {
                return this.message;
            }
        }
                
        public AlumnoRepetidoException()
        {
        }
    }
}
