﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Universidad
    {
        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        #region propiedades

        /// <summary>
        ///  retorna o setea la lista de alumnos
        /// </summary>
        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }

            set
            {
                this.Alumnos = value;
            }
        }

        /// <summary>
        ///  retorna o setea la lista de profesores
        /// </summary>
        public List<Profesor> Instructores
        {
            get
            {
                return this.profesores;
            }

            set
            {
                this.Instructores = value;
            }
        }

        /// <summary>
        ///  retorna o setea la lista de jornadas
        /// </summary>
        public List<Jornada> Jornadas
        {
            get
            {
                return this.jornada;
            }

            set
            {
                this.jornada = value;
            }
        }

        /// <summary>
        ///  retorna o setea la jornada indicada
        /// </summary>
        public Jornada this[int i]
        {
            get
            {
                Jornada retorno;

                if (i > 0 && i < this.Jornadas.Count)
                {
                    retorno = this.Jornadas.ElementAt(i);
                }
                else if (i >= this.Jornadas.Count)
                {
                    retorno = this.Jornadas.Last();
                }
                else
                {
                    retorno = this.Jornadas.FirstOrDefault();
                }

                return retorno;
            }

            set
            {
                this.jornada.Insert(i, value);
            }
        }

        #endregion

        #region constructores

        /// <summary>
        /// inicializa las tres listas de la universidad
        /// </summary>
        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.jornada = new List<Jornada>();
            this.profesores = new List<Profesor>();
        }

        #endregion

        #region métodos

        /// <summary>
        /// guarda un objeto del tipo universidad en un archivo XML
        /// </summary>
        /// <param name="uni"> universidad a guardar </param>
        /// <returns> retorna true si se guardo, false si no </returns>
        public static bool Guardar(Universidad uni)
        {
            bool retorno;

            IArchivo<Universidad> archivo = new Xml<Universidad>();

            retorno = archivo.Guardar("Universidad.xml", uni);

            return retorno;
        }

        /// <summary>
        /// lee un archivo XML con datos del tipo universidad
        /// </summary>
        /// <returns> retorna los datos del tipo universidad en un string </returns>
        public string Leer()
        {
            IArchivo<Universidad> archivo = new Xml<Universidad>();
            Universidad datos;
            archivo.Leer("Universidad.xml", out datos);

            return datos.ToString();
        }

        /// <summary>
        /// retorna los datos de la universidad
        /// </summary>
        /// <param name="uni"> universidad a mostrar </param>
        /// <returns> retorna los datos en un string </returns>
        private static string MostrarDatos(Universidad uni)
        {
            StringBuilder retorno = new StringBuilder();

            foreach (Jornada jornada in uni.Jornadas)
            {
                retorno.AppendLine(jornada.ToString());
            }

            return retorno.ToString();
        }

        #endregion

        #region sobrecargas

        /// <summary>
        /// verifica si el alumno esta inscripto en la universidad
        /// </summary>
        /// <param name="g"> universidad a comparar </param>
        /// <param name="a"> alumno a comparar </param>
        /// <returns> retorna true si esta inscripto, false si no lo esta </returns>
        public static bool operator ==(Universidad g, Alumno a)
        {
            bool retorno = false;

            foreach (Alumno alumnoAux in g.Alumnos)
            {
                if (alumnoAux == a)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el alumno no esta inscripto en la universidad
        /// </summary>
        /// <param name="g"> universidad a comparar </param>
        /// <param name="a"> alumno a comparar </param>
        /// <returns> retorna true si no esta inscripto, false si lo esta </returns>
        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        /// <summary>
        /// inscribe un alumno a la universidad, previa validacion
        /// </summary>
        /// <param name="g"> universidad en la que se inscribe </param>
        /// <param name="a"> alumno a inscribir </param>
        /// <returns> retorna una universidad con el alumno inscripto </returns>
        public static Universidad operator +(Universidad g, Alumno a)
        {
            Universidad retorno = g;

            if (g != a)
            {
                retorno.Alumnos.Add(a);
            }
            else
            {
                throw new AlumnoRepetidoException();
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el profesor da clases en la universidad
        /// </summary>
        /// <param name="g"> universidad a comparar </param>
        /// <param name="i"> profesor a comparar </param>
        /// <returns> retorna true si da clases, false si no da </returns>
        public static bool operator ==(Universidad g, Profesor i)
        {
            bool retorno = false;

            foreach (Profesor auxProfesor in g.Instructores)
            {
                if (auxProfesor == i)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el profesor no da clases en la universidad
        /// </summary>
        /// <param name="g"> universidad a comparar </param>
        /// <param name="i"> profesor a comparar </param>
        /// <returns> retorna true si no da clases, false si da  </returns>
        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        /// <summary>
        /// inscribe un profesor a la universidad, previa validacion
        /// </summary>
        /// <param name="g"> universidad en la que se inscribe </param>
        /// <param name="i"> profesor a inscribir </param>
        /// <returns> retorna una universidad con el profesor inscripto </returns>
        public static Universidad operator +(Universidad g, Profesor i)
        {
            Universidad retorno = g;

            if (g != i)
            {
                retorno.Instructores.Add(i);
            }

            return retorno;
        }

        /// <summary>
        /// busca un profesor que pueda dar la clase
        /// </summary>
        /// <param name="u"> universidad en la que se busca el profesor </param>
        /// <param name="clase"> clase que necesita profesor </param>
        /// <returns> retorna el primer profesor que pueda dar la clase </returns>
        public static Profesor operator ==(Universidad u, EClases clase)
        {
            Profesor retorno = null;

            foreach (Profesor profesor in u.Instructores)
            {
                if (profesor == clase)
                {
                    retorno = profesor;
                    break;
                }
            }

            if (retorno is null)
            {
                throw new SinProfesorException();
            }

            return retorno;
        }

        /// <summary>
        /// busca un profesor que no pueda dar la clase
        /// </summary>
        /// <param name="u"> universidad en la que se busca el profesor </param>
        /// <param name="clase"> clase que necesita profesor </param>
        /// <returns> retorna el primer profesor que no pueda dar la clase </returns>
        public static Profesor operator !=(Universidad u, EClases clase)
        {
            Profesor retorno = null;

            foreach (Profesor profesor in u.Instructores)
            {
                if (profesor != clase)
                {
                    retorno = profesor;
                    break;
                }
            }

            if (retorno is null)
            {
                throw new SinProfesorException();
            }

            return retorno;
        }

        /// <summary>
        /// se agregara una clase a una jornada, y se le indicara un profesor que la de
        /// </summary>
        /// <param name="g"> univiersidad donde se agregara la clase </param>
        /// <param name="clase"> clase que se agregara </param>
        /// <returns></returns>
        public static Universidad operator +(Universidad g, EClases clase)
        {
            Universidad retorno = g;
            Jornada jornada;

            jornada = new Jornada(clase, g == clase);
            foreach (Alumno alumno in g.Alumnos)
            {
                if (alumno == clase)
                {
                    jornada.Alumnos.Add(alumno);
                }
            }

            retorno.Jornadas.Add(jornada);

            return retorno;
        }

        /// <summary>
        /// retorna los datos de un objeto de tipo universidad
        /// </summary>
        /// <returns> retorna todos los datos en un string </returns>
        public override string ToString()
        {
            return MostrarDatos(this);
        }

        #endregion

        #region enumerados

        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        #endregion
    }
}
