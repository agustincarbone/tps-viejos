﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClasesInstanciables.Universidad;
using Archivos;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private EClases clase;
        private Profesor instructor;

        #region propiedades

        /// <summary>
        ///  retorna o setea la lista de alumnos de la jornada
        /// </summary>
        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }

            set
            {
                this.alumnos = value;
            }
        }

        /// <summary>
        /// retorna o setea las clases de la jornada
        /// </summary>
        public EClases Clase
        {
            get
            {
                return this.clase;
            }

            set
            {
                this.clase = value;
            }
        }

        /// <summary>
        /// retorna o setea el profesor de la jornada
        /// </summary>
        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }

            set
            {
                this.instructor = value;
            }
        }

        #endregion

        #region constructores

        /// <summary>
        /// inicializa la lista de alumnos
        /// </summary>
        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }

        /// <summary>
        /// inicializa un objeto del tipo jornada
        /// </summary>
        /// <param name="clase"> clase que se da en la jornada </param>
        /// <param name="instructor"> profesor que da la clase </param>
        public Jornada(EClases clase, Profesor instructor) : this()
        {
            this.Clase = clase;
            this.Instructor = instructor;
        }

        #endregion

        #region métodos

        /// <summary>
        /// guarda los datos de la jornada en un archivo de texto
        /// </summary>
        /// <param name="jornada"> jornada que se va a guardar </param>
        /// <returns> retorna true si se pudo guardar, caso contrario,
        /// retorna false </returns>
        public static bool Guardar(Jornada jornada)
        {
            bool retorno = false;
            IArchivo<string> archivo = new Texto();
                        
            if (archivo.Guardar("Jornada.txt", jornada.ToString()))
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// lee los datos de un archivo de texto
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        public string Leer()
        {
            IArchivo<string> archivo = new Texto();
            string datos;
            archivo.Leer("Jornada.txt", out datos);

            return datos;
        }

        #endregion

        #region sobrecargas

        /// <summary>
        /// verifica si el alumno esta inscripto en la jornada
        /// </summary>
        /// <param name="j"> jornada a verificar </param>
        /// <param name="a"> alumno a verificar </param>
        /// <returns>  retorna true si el alumno esta inscripto, caso contrario,
        /// retorna false </returns>
        public static bool operator ==(Jornada j, Alumno a)
        {
            bool retorno = false;

            if (a == j.clase)
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el alumno no esta inscripto en la jornada
        /// </summary>
        /// <param name="j"> jornada a verificar </param>
        /// <param name="a"> alumno a verificar </param>
        /// <returns>  retorna true si el alumno no esta inscripto, caso contrario,
        /// retorna false </returns>
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        /// <summary>
        /// inscribe un alumno a la jornada
        /// </summary>
        /// <param name="j">jornada en la que se va a inscribir </param>
        /// <param name="a"> alumno a inscribir </param>
        /// <returns> retorna la jornada con el alumno inscripto </returns>
        public static Jornada operator +(Jornada j, Alumno a)
        {
            Jornada retorno = j;

            if (j != a)
            {
                retorno.alumnos.Add(a);
            }

            return retorno;
        }

        /// <summary>
        /// retorna los datos de un objeto de tipo jornada
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Jornada: ");

            retorno.AppendFormat("Clase de {0} Por {1} ",this.Clase.ToString(), this.Instructor.ToString());

            retorno.AppendLine("Alumnos: ");

            foreach (Alumno alumno in this.alumnos)
            {
                retorno.AppendLine(alumno.ToString());
            }

            retorno.AppendLine("<----------------------------------------->\n");

            return retorno.ToString();
        }

        #endregion
    }
}
