﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
using static ClasesInstanciables.Universidad;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<EClases> clasesDelDia;
        private static Random random;

        #region constructores

        /// <summary>
        /// inicializa el valor estatico random
        /// </summary>
        static Profesor()
        {
            random = new Random();
        }

        /// <summary>
        ///  inicializa la cola de clases y le asigna dos clases 
        ///  al azar al profesor
        /// </summary>
        public Profesor()
        {
            this.clasesDelDia = new Queue<EClases>();
            this._randomClases();
        }

        /// <summary>
        /// inicializa un objeto del tipo profesor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad) 
        {
            this.clasesDelDia = new Queue<EClases>();
            this._randomClases();
        }

        #endregion

        #region métodos

        /// <summary>
        /// asigna dos clases al azar al profesor
        /// </summary>
        private void _randomClases()
        {
            var array = Enum.GetValues(typeof(EClases));
            this.clasesDelDia.Enqueue((EClases)array.GetValue(random.Next(array.Length)));
            this.clasesDelDia.Enqueue((EClases)array.GetValue(random.Next(array.Length)));
        }

        #endregion

        #region sobrecargas

        /// <summary>
        /// retorna los datos de un objeto de tipo profesor
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("{0}{1} \n", base.MostrarDatos(), this.ParticiparEnClase());

            return retorno.ToString();
        }

        /// <summary>
        /// verifica si el profesor da la clase
        /// </summary>
        /// <param name="i"> profesor a verificar </param>
        /// <param name="clase"> clase a verificar </param>
        /// <returns> retorna true si da la clase, caso contrario,
        /// retorna false </returns>
        public static bool operator ==(Profesor i, EClases clase)
        {
            bool retorno = false;

            foreach (EClases auxClase in i.clasesDelDia)
            {
                if (auxClase == clase)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el profesor no da la clase
        /// </summary>
        /// <param name="i"> profesor a verificar </param>
        /// <param name="clase"> clase a verificar </param>
        /// <returns> retorna true si no da la clase, caso contrario,
        /// retorna false </returns>
        public static bool operator !=(Profesor i, EClases clase)
        {
            return !(i == clase);
        }

        /// <summary>
        /// retorna las clases que da el profesor
        /// </summary>
        /// <returns> retorna las clases en un string </returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Clases del Dia");

            foreach (EClases clase in clasesDelDia)
            {
                retorno.AppendLine(clase.ToString());
            }

            return retorno.ToString();
        }

        /// <summary>
        /// retorna los datos de un objeto del tipo profesor
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }

        #endregion
    }
}
