﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void BtnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnConvertirABinario_Click(object sender, EventArgs e)
        {
            string resultado;

            if(lblResultado.Text != null)
            {
                resultado = Numero.DecimalBinario(lblResultado.Text);
            }
            else
            {
                resultado = "no hay resultado para convertir";
            }

            lblResultado.Text = resultado;
        }

        private void BtnConvertirADecimal_Click(object sender, EventArgs e)
        {
            string resultado;

            if (lblResultado.Text != null)
            {
                resultado = Numero.BinarioDecimal(lblResultado.Text);
            }
            else
            {
                resultado = "no hay resultado para convertir";
            }

            lblResultado.Text = resultado;
        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void BtnOperar_Click(object sender, EventArgs e)
        {
            double resultado;

            resultado = Operar(txtNumero1.Text, txtNumero2.Text, cmbOperador.Text);
            lblResultado.Text = resultado.ToString();
        }

        /// <summary>
        /// reestablece los casilleros del formulario a los valores predeterminados
        /// </summary>
        private void Limpiar()
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            cmbOperador.Text = "  ";
            lblResultado.Text = "  ";
        }

        /// <summary>
        /// llama al metodo operar pasando los datos de tipo string como datos de
        /// tipo Numero
        /// </summary>
        /// <param name="numero1"> string que indica el primer numero </param>
        /// <param name="numero2"> string que indica el primer numero </param>
        /// <param name="operador"> caracter que indica la operacion a realizar </param>
        /// <returns> retorna el resultado de la operacion </returns>
        private static double Operar(string numero1, string numero2, string operador)
        {
            Numero auxNum1 = new Numero(numero1);
            Numero auxNum2 = new Numero(numero2);

            return Calculadora.Operar(auxNum1, auxNum2, operador);
        }
    }
}
