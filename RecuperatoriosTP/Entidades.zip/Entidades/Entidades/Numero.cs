﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;

        /// <summary>
        /// asigna el valor indicado, luego de validarlo, al atributo
        /// </summary>
        private string SetNumero
        {
            set
            {
                numero = ValidarNumero(value);
            }
        }

        /// <summary>
        /// inicializa el atributo con el valor 0
        /// </summary>
        public Numero()
        {
            SetNumero = "0";
        }

        /// <summary>
        /// inicializa el atributo con el valor indicado
        /// </summary>
        /// <param name="numero"> valor que se va a cargar </param>
        public Numero(double numero)
        {
            SetNumero = numero.ToString();
        }

        /// <summary>
        /// inicializa el atributo con el valor indicado
        /// </summary>
        /// <param name="strNumero"> valor que se va a cargar </param>
        public Numero(string strNumero)
        {
            SetNumero = strNumero;
        }

        /// <summary>
        /// convierte el resultado del calculo a decimal
        /// </summary>
        /// <param name="binario"> valor tipo string en sistema binario</param>
        /// <returns> retorna el resultado de la conversion en formato string </returns>
        public static string BinarioDecimal(string binario)
        {
            int i;
            int sum = 0;
            bool esBinario = true;
            string retorno = "valor invalido";

            for (i = 0; i < binario.Length; i++)
            {
                if (binario[i] != '0' && binario[i] != '1')
                {
                    esBinario = false;
                }
            }

            if (esBinario == true)
            {
                char[] array = binario.ToCharArray();
                Array.Reverse(array);

                for (i = 0; i < array.Length; i++)
                {
                    if (array[i] == '1')
                    {
                        sum += (int)Math.Pow(2, i);
                    }
                }

                retorno = sum.ToString();
            }

            return retorno;
        }

        /// <summary>
        /// convierte el resultado del calculo a binario
        /// </summary>
        /// <param name="numero"> valor tipo double en sistema decimal </param>
        /// <returns> retorna el resultado de la conversion </returns>
        public static string DecimalBinario(double numero)
        {
            string retorno = "valor invalido";

            if (numero >= 0)
            {
                string cadena = "";

                do
                {
                    if (numero % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    numero = (int)(numero / 2);
                } while (numero > 0);

                retorno = cadena;
            }

            return retorno;

        }

        /// <summary>
        /// convierte el resultado del calculo a binario
        /// </summary>
        /// <param name="numero"> valor tipo string en sistema binario </param>
        /// <returns> retorna el resultado de la conversion </returns>
        public static string DecimalBinario(string numero)
        {
            double aux;
            string retorno = "valor invalido";

            if (double.TryParse(numero, out aux))
            {
                retorno = DecimalBinario(double.Parse(numero));
            }

            return retorno;
        }

        public static double operator -(Numero num1, Numero num2)
        {
            double resultado;

            resultado = num1.numero - num2.numero;

            return resultado;
        }

        public static double operator *(Numero num1, Numero num2)
        {
            double resultado;

            resultado = num1.numero * num2.numero;

            return resultado;
        }

        public static double operator /(Numero num1, Numero num2)
        {
            double resultado;

            if (num2.numero == 0)
            {
                resultado = double.MinValue;
            }
            else
            {
                resultado = num1.numero / num2.numero;
            }

            return resultado;
        }

        public static double operator +(Numero num1, Numero num2)
        {
            double resultado;

            resultado = num1.numero + num2.numero;

            return resultado;
        }

        /// <summary>
        /// valida que el valor del tipo string sea un numero
        /// </summary>
        /// <param name="strNumero"> valor a verificar </param>
        /// <returns> si el string se puede parsear, lo devuelve con formato double,
        /// caso contrario, devuelve 0 </returns>
        private double ValidarNumero(string strNumero)
        {
            double auxNum;
            double retorno = 0;

            if (double.TryParse(strNumero, out auxNum))
            {
                retorno = auxNum;
            }

            return retorno;
        }
    }
}
