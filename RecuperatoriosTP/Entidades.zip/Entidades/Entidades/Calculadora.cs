﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class Calculadora
    {
        /// <summary>
        /// realiza una operacion a partir del operador indicado
        /// </summary>
        /// <param name="num1"> primer valor del calculo </param>
        /// <param name="num2"> segundo valor del calculo </param>
        /// <param name="operador"> caracter que indica el calculo a realizar </param>
        /// <returns> si la operacion se puede realizar devuelve el resultado,
        /// caso contrario, devuelve 0 </returns>
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            string auxOperador = ValidarOperador(operador);
            Double resultado = 0;

            switch (auxOperador)
            {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "/":
                    resultado = num1 / num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
            }

            return resultado;
        }

        /// <summary>
        /// valida si el operador indicado coincide con alguno de los caracteres
        /// validos
        /// </summary>
        /// <param name="operador"> operador a verificar </param>
        /// <returns> si el operador coincide lo devuelve,
        /// caso contrario devuelve el operador "+" </returns>
        private static string ValidarOperador(string operador)
        {
            string retorno = "+";

            if (operador != null)
            {
                if ((operador == "+") || (operador == "-") || (operador == "/") || (operador == "*"))
                {
                    retorno = operador;
                }
            }

            return retorno;
        }
    }
}
