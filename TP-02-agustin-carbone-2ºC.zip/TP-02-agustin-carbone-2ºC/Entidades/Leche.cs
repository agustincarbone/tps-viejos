﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;

namespace Entidades_2018
{
    public class Leche : Producto
    {
        public enum Tipo
        {
            Entera,
            Descremada
        }

        private Tipo tipo;

        /// <summary>
        /// Por defecto, TIPO será ENTERA / Inicializa un objeto del tipo leche 
        /// </summary>
        /// <param name="marca">Marca de la leche</param>
        /// <param name="patente">Patente de la leche</param>
        /// <param name="color">Color del envase de la leche</param>
        public Leche(Marca marca, string patente, ConsoleColor color) : base(patente, marca, color)
        {
            this.tipo = Leche.Tipo.Entera;
        }

        /// <summary>
        /// Inicializa un objeto del tipo leche del TIPO especificado
        /// </summary>
        /// <param name="marca">Marca de la leche</param>
        /// <param name="patente">Patente de la leche</param>
        /// <param name="color">Color del envase de la leche</param>
        /// <param name="tipo">Tipo de la leche</param>
        public Leche(Producto.Marca marca, string patente, ConsoleColor color, Leche.Tipo tipo) : base(patente, marca, color)
        {
            this.tipo = tipo;
        }

        /// <summary>
        /// Las leches tienen 20 calorías / Retorna la cantidad de calorias que contiene la leche
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 20;
            }
        }

        /// <summary>
        /// Muestra TODOS los datos del objeto Leche
        /// </summary>
        /// <returns>Retorna un string con los datos del objeto</returns>
        public override sealed string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("LECHE");
            cadena.AppendLine(base.Mostrar());
            cadena.AppendFormat("CALORIAS : {0}", this.CantidadCalorias);
            cadena.AppendLine("TIPO : " + this.tipo);
            cadena.AppendLine("");
            cadena.AppendLine("---------------------");

            return cadena.ToString();
        }
    }
}
