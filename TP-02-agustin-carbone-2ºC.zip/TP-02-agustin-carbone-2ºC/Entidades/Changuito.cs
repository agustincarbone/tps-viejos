﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    /// <summary>
    /// No podrá tener clases heredadas.
    /// </summary>
    public sealed class Changuito
    {
        private List<Producto> productos;
        private int espacioDisponible;

        public enum Tipo
        {
            Dulce,
            Leche,
            Snacks,
            Todos
        }

        #region "Constructores"

        /// <summary>
        /// Inicializa una nueva lista de la clase Changuito
        /// </summary>
        private Changuito()
        {
            this.productos = new List<Producto>();
        }

        /// <summary>
        /// Inicializa una nueva lista de la clase Changuito con un espacio especificado
        /// </summary>
        /// <param name="espacioDisponible"> esapcio maximo que tendrá el changuito</param>
        public Changuito(int espacioDisponible) : this()
        {
            this.espacioDisponible = espacioDisponible;
        }
        #endregion

        #region "Sobrecargas"
        /// <summary>
        /// Muestro el Changuito y TODOS los Productos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Changuito.Mostrar(this, Changuito.Tipo.Todos);
        }
        #endregion

        #region "Métodos"

        /// <summary>
        /// Expone los datos del elemento y su lista (incluidas sus herencias)
        /// SOLO del tipo requerido
        /// </summary>
        /// <param name="changuito">Elemento a exponer</param>
        /// <param name="Tipo">Tipos de ítems de la lista a mostrar</param>
        /// <returns></returns>
        public static string Mostrar(Changuito changuito, Tipo tipo)
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendFormat("Tenemos {0} lugares ocupados de un total de {1} disponibles", changuito.productos.Count, changuito.espacioDisponible);
            cadena.AppendLine("");
            foreach (Producto producto in changuito.productos)
            {
                switch (tipo)
                {
                    case Changuito.Tipo.Snacks:
                        if (producto is Snacks)
                        {
                            cadena.AppendLine(producto.Mostrar());
                            break;
                        }
                        break;
                    case Changuito.Tipo.Dulce:
                        if (producto is Leche)
                        {
                            cadena.AppendLine(producto.Mostrar());
                            break;
                        }
                        break;
                    case Changuito.Tipo.Leche:
                        if (producto is Dulce)
                        {
                            cadena.AppendLine(producto.Mostrar());
                            break;
                        }
                        break;
                    default:
                        cadena.AppendLine(producto.Mostrar());
                        break;
                }
            }

            return cadena.ToString();
        }
        #endregion

        #region "Operadores"
        /// <summary>
        /// Agregará un elemento a la lista
        /// </summary>
        /// <param name="changuito">Objeto donde se agregará el elemento</param>
        /// <param name="producto">Objeto a agregar</param>
        /// <returns></returns>
        public static Changuito operator +(Changuito changuito, Producto producto)
        {
            Changuito retorno;
            bool confirmacion = false;

            if (changuito.productos.Count >= changuito.espacioDisponible)
            {
                retorno = changuito;
            }
            else
            {
                foreach (Producto auxProducto in changuito.productos)
                {
                    if (auxProducto == producto)
                    {                       
                        confirmacion = true;
                    }
                }

                if(confirmacion == false)
                {
                    changuito.productos.Add(producto);
                }
                retorno = changuito;
            }

            return retorno;
        }
        /// <summary>
        /// Quitará un elemento de la lista
        /// </summary>
        /// <param name="Changuito">Objeto donde se quitará el elemento</param>
        /// <param name="producto">Objeto a quitar</param>
        /// <returns></returns>
        public static Changuito operator -(Changuito Changuito, Producto producto)
        {
            foreach (Producto auxProducto in Changuito.productos)
            {
                if (auxProducto == producto)
                {
                    Changuito.productos.Remove(producto);
                    break;
                }
            }

            return Changuito;
        }
        #endregion
    }
}
